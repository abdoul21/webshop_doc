<?php
include "../bdd.php";

//Si methode post ajouter existe ou le bouton ajouter est appuyé
if (isset($_POST['ajouter'])) {
    $nom      = $_POST["nom"];
    $prenom   = $_POST["prenom"];
    $email   = $_POST["email"];
    $adresse  = $_POST["adresse"];
    $sexe   = $_POST["sexe"];
    $age   = $_POST["age"];
    $telephone   = $_POST["telephone"];
    $password   = $_POST["password"];
    $verif_mdp   = $_POST["password_repeat"];
    $id_role = 2;

    //On verifie si la verification du mot de passe se fait bien
    if ($password != $verif_mdp) {
        //on affichage un message d'information en javascript
        $message_erro = "les mots de passe ne sont pas identiques";
        echo "<script type='text/javascript'>alert('$message_erro'); document.location.href = 'register.html'</script>";

    }
    else {
        //On vérifie si le format de l'email est valide
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

            //on hache le mot de passe avec un algorithme
            $pass_hache = md5($password);

            //on insere dans la base de donnée
            // préparer votre requête pour insérer des données dans la table
            $inserer = "insert into utilisateurs (nom,prenom,sexe,age,adresse,email,telephone,password,id_role) values ('$nom','$prenom','$sexe','$age','$adresse','$email','$telephone','$pass_hache',$id_role)";

            // exécuter la requête avec la focntion PHP
            mysqli_query($bdd, $inserer);

            // fermeture de la connexion avec la base de données
            mysqli_close($bdd);

            //on affichage un message d'information en javascript
            $message = $nom." ".$prenom." a été ajouté";

            echo "<script type='text/javascript'>alert('$message'); document.location.href = '../connexion/login.html'</script>";
        }
        /*else {

            //redirection vers page d'erreur correspondant
           // header('Location: erreur/erreur_email.php');
        }*/
    }
}

    

?>


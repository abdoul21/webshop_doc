<?php

include_once("../../bdd.php");
$result = mysqli_query($bdd, "SELECT * FROM utilisateurs ORDER BY idmembre DESC");
?>

<html>

<head>
    <title>Page Acceuil</title>
</head>

<body>
    <p><u> Administration de vos données </u></p>
    <br />
    <table width="60%" border=0>
        <tr bgcolor="#CCCCCC">
            <th>ID</th>
            <th>Nom</th>
            <th>Prenom</th>
            <th>Sexe</th>
            <th>Age</th>
            <th>Adresse</th>
            <th>Email</th>
            <th>Telephone</th>
            <th>Id_role</th>
            <th>Option_Admin</th>
            
        </tr>


                    <!-- Si notre requete ne retourne pas de valeurs vide -->
                    <?php if (!empty($result)): ?>

        <!-- On va parcourir les données qui sont dans la base afin de pouvoir les afficher -->
                        <?php foreach ($result as $value): ?>
                            
                            <tr>
                                <td>

                                        <?php echo $value["idmembre"]; ?>
                                </td>
                                <td>
                                    <?php echo $value["nom"]; ?>
                                   
                                    </td>
                                <td>
                                   <?php echo $value["prenom"]; ?>
                                    </td>
                                <td>
                                    <?php echo $value["sexe"]; ?>
                                   </td>
                                <td>
                                    
                                    <?php echo $value["age"];?></td>
                                <td>
                                    
                                    <?php echo $value["adresse"];?></td>
                                <td>
                                    
                                    <?php echo $value["email"];?></td>
                                <td>
                                   
                                    <?php echo $value["telephone"];?></td>


                                <td>
                                   
                                    <?php echo $value["id_role"];?></td>
                                <td>
                                <a href="modifie.php?id=<?php echo $value["idmembre"] ?>"><button type="button" name="button">Modifier</button></a> 
                                </td>
                                 <td>
                                <a href="supprimer.php?id=<?php echo $value["idmembre"] ?>"><button type="button" name="button">supprimer</button></a> 
                                </td>
                            </tr>

                        <?php endforeach ?>
                    
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center">Pas de données disponibles!</td>
                        </tr>
                    <?php endif ?>
                    
                </tbody>
            </table>
        </section>

    </div>
    </table>



</body>

</html>


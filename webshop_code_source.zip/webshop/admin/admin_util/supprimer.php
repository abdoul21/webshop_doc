 
   <<?php 

   include '..\..\bdd.php';


    //********************* POUR LA SUPPRESSION *************************
    //On vérifie si le bouton supprimer est appuyer
    if(isset($_POST['supprimer'])){

        //On récupère les valeurs qu'on a saisir dans le formulaire. 
        $idmembre = $_POST['idmembre'];

        //Preparation de la requête de suppresion dans la base : 
        $stmt = $conn->prepare("DELETE FROM utilisateurs WHERE idmembre=?");
        $stmt->bindParam(1, $idmembre);

        //On va exécuter notre requête
        $stmt->execute();

    }

    //********************* POUR L'AFFICHAGE *************************
    //Preparation de la requête : 
    $id = $_GET['id'];
    $aff = $conn->prepare("SELECT * FROM utilisateurs WHERE idmembre=$id");


    //On va exécuter notre requête
    $aff->execute();

    //On récupère tous les données 
    $users = $aff->fetchAll();

    ?>



  <!-- MODAL POUR SUPPRESSION -->
    <?php foreach ($users as $value): ?>
        <!-- The Modal -->
        <div class="modal" id="myModalSup<?php echo $value["idmembre"];?>">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST" action="">
                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h4 class="modal-title">Suppression</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>

                        <!-- Modal body -->
                        <div class="modal-body">
                            <input type="hidden" name="idmembre" class="form-control" value="<?php echo $value["idmembre"]; ?>">
                            <h4>Voulez-vous supprimer <strong><?php echo $value["nom"]." ".$value["prenom"];?></strong> définitivement?</h4>
                        </div>

                        <!-- Modal footer -->
                        <div class="modal-footer">
                            <button type="submit" name="supprimer" class="btn btn-primary">Supprimer</button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach ?>


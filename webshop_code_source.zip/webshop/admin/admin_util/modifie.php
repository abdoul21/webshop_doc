<?php

include '..\..\bdd.php';

    //********************* POUR LA MODIFICATION *************************
    //On vérifie si le bouton modifier est appuyer
    if(isset($_POST['modifier'])){

        //On récupère les valeurs qu'on a saisi dans le formulaire. 
        
        $idmembre = $_POST['idmembre'];
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $sexe = $_POST['sexe'];
        $age = $_POST['age'];
        $adresse = $_POST['adresse'];
        $email = $_POST['email'];
        $telephone = $_POST['telephone'];

        //Preparation de la requête de modification dans la base : 
        $stmt = $conn->prepare("UPDATE utilisateurs SET nom=?, prenom=?,sexe=?,age=?,adresse=?,email=?,telephone=? WHERE idmembre=$idmembre");
        $stmt->bindparam(1, $nom);
        $stmt->bindparam(2, $prenom);
        $stmt->bindparam(3, $sexe);
        $stmt->bindparam(4, $age);
        $stmt->bindparam(5, $adresse);
        $stmt->bindparam(6, $email);
        $stmt->bindparam(7, $telephone);

        //On va exécuter notre requête
        $stmt->execute();

    }


    //********************* POUR L'AFFICHAGE *************************
    //Preparation de la requête : 
    $id = $_GET['id'];
    $aff = $conn->prepare("SELECT * FROM utilisateurs WHERE idmembre=$id");


    //On va exécuter notre requête
    $aff->execute();

    //On récupère tous les données 
    $users = $aff->fetchAll();




// MODAL POUR MODIFICATION 
     foreach ($users as $value): ?>
        <!-- The Modal -->
        <div class="modal" id="myModal<?php echo $value["idmembre"];?>">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST" action="">
                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h4 class="modal-title">Modification</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>

                        <!-- Modal body -->
                        <div class="modal-body">

                            <div class="form-row">
                                <input type="hidden" name="idmembre" class="form-control" value="<?php echo $value["idmembre"]; ?>">
                                <div class="form-group col-md-6">
                                    <label>Nom</label>
                                    <input type="text" name="nom" class="form-control" value="<?php echo $value["nom"]; ?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Prenom</label>
                                    <input type="text" name="prenom" class="form-control" value="<?php echo $value["prenom"]; ?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Sexe</label>
                                    <input type="text" name="sexe" class="form-control" value="<?php echo $value["sexe"]; ?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Age</label>
                                    <input type="text" name="age" class="form-control" value="<?php echo $value["age"]; ?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Adresse</label>
                                    <input type="text" name="adresse" class="form-control" value="<?php echo $value["adresse"]; ?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Email</label>
                                    <input type="text" name="email" class="form-control" value="<?php echo $value["email"];?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Telephone</label>
                                    <input type="text" name="telephone" class="form-control" value="<?php echo $value["telephone"];?>" required>
                                </div>
                            </div>
                        </div>

                        <!-- Modal footer -->
                        <div class="modal-footer">
                            <button type="submit" name="modifier" class="btn btn-primary">Modifier</button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach ?>


</body>
</html>


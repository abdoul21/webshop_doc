<?php
include("../../bdd.php");
session_start();
if ($_SESSION['id_role']==1 && $_SESSION['idmembre']){

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>supprimer</title>
    <?php include ("../../icon_ongle.php");?>

</head>

<body>
    <?php


    $id_bonne_affaire = $_GET['id'];
    echo "<script type='text/javascript'>alert('bonne_affaire supprimé'); document.location.href = 'admine_bonne_affaire.php'</script>";
    // requête de suppression
    $sql = "DELETE FROM bonne_affaire WHERE id_bonne_affaire=$id_bonne_affaire";

    // exécuter la requête avec la fonction PHP
    mysqli_query($bdd, $sql);

    // fermeture de la connexion avec la base de données
    mysqli_close($bdd);

    ?>


</body>

</html>
<?php }  else{
  header('Location: ../../403.html');
die();
}?>

<?php
include ("bdd.php");
session_start();
if ($_SESSION['id_role']==2){
$image = htmlentities($_POST['image'], ENT_QUOTES,'UTF-8');
$produit = htmlentities($_POST["produit"], ENT_QUOTES,'UTF-8');
$prix = htmlentities($_POST["prix"], ENT_QUOTES,'UTF-8');
$quantiter = htmlentities($_POST['qte'], ENT_QUOTES,'UTF-8');
$prenom = htmlentities($_SESSION['prenom'], ENT_QUOTES,'UTF-8');
$statue = "non-livrer";
    $total =  ($quantiter * $prix);

try {
    
    $stmt = $conn->prepare("SELECT idreserv FROM reservation ORDER BY idreserv DESC LIMIT 1");
    $stmt->execute();
    $resultat = $stmt->fetch();
    $num=$resultat['idreserv'];

    $stm = $conn->prepare("SELECT qte FROM produit where produit='" . $produit . "' ");
    $stm->execute();
    $res = $stm->fetch();
    $pqte = $res['qte'];
    $quantiter_totale =($pqte - $quantiter);

    if (empty($num)) {
        $num=0;
}
        $num++;
        $sql = "INSERT INTO reservation(idreserv, NC, Nomclient, Produit, Date, qte, prix, statue, image)
    VALUES (null, '$num', '$prenom', '$produit', CURDATE(),'$quantiter','$total','$statue','$image')";
    // use exec() because no results are returned
    $conn->exec($sql);

    $mja = "UPDATE produit SET  qte='" . $quantiter_totale. "' WHERE produit='" . $produit . "'";

    mysqli_query($bdd, $mja);

    mysqli_close($bdd);

    }
    catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }
    echo "<script type='text/javascript'>alert('votre réservation a été confirmé'); document.location.href = 'produit.php'</script>";

}else{
    echo "<script type='text/javascript'>alert('veuillez-vous connecter ou vous inscrire'); document.location.href = 'index.php'</script>";

}
?>